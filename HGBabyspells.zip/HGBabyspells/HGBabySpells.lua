---------------------------
-------HGBabySpells--------
---------------------------
--WoWClassicWOTLK
--I will add a shiny red button with green text to your character's spellbook. Click the button to activate!


local spellData, highlighted = {}, {};
local defaultBars = {"Action", "MultiBarBottomLeft", "MultiBarBottomRight", "MultiBarRight", "MultiBarLeft"};

local function getSpellData()
    spellData = {};
    for tab = 1, GetNumSpellTabs() do
        local name, texture, offset, numSlots, isGuild, offspecID = GetSpellTabInfo(tab);
        for i = offset + 1, offset + numSlots do
            local spellName, spellSubText, spellID = GetSpellBookItemName(i, BOOKTYPE_SPELL);
            local rank = strmatch(spellSubText, "%d+");
            if rank then
                rank = tonumber(rank);
                if rank > 0 and (not spellData[spellName] or rank > spellData[spellName]) then
                    spellData[spellName] = rank;
                end
            end
        end
    end
    return spellData;
end

local function scanBars(spellData, count)
    count = count or 0;
    for _, barName in ipairs(defaultBars) do
        for i = 1, 12 do
            local button = _G[barName .. "Button" .. i];
            if button then
                local slot = button.action;
                if slot and HasAction(slot) then
                    local spellID = 0;
                    local actionType, id = GetActionInfo(slot);
                    if actionType == "macro" then
                        spellID = GetMacroSpell(id);
                    elseif actionType == "spell" then
                        spellID = id;
                    end
                    if spellID and spellID > 0 then
                        local spell = Spell:CreateFromSpellID(spellID);
                        spell:ContinueOnSpellLoad(function()
                            local spellName = spell:GetSpellName();
                            local spellSubText = spell:GetSpellSubtext();
                            local rank = strmatch(spellSubText, "%d+");
                            if rank then
                                rank = tonumber(rank);
                                if rank and spellData[spellName] and rank < spellData[spellName] then
                                    count = count + 1;
                                    ActionButton_ShowOverlayGlow(button);
                                    tinsert(highlighted, button);
                                    local text = "|cFFFF0000Bar " .. barName .. " Slot " .. i .. ":|r " .. GetSpellLink(spellID) .. " |cFF9CD6DE(" .. RANK .. " " .. rank .. ")|r";
                                    text = text .. " |cFFFF6900Not Max Rank.|r";
                                    print(text);
                                end
                            end
                        end);
                    end
                end
            end
        end
    end
    return count;
end

local function removeAllHighlighted()
    for _, button in ipairs(highlighted) do
        ActionButton_HideOverlayGlow(button);
    end
    wipe(highlighted);
end

local function scanHotbars()
    removeAllHighlighted();
    local count = scanBars(getSpellData());
    print("HealGuys Baby Spell Checker: " .. count .. " spells with lower ranks on hotbars.");
end

-- scans both the default UI and Bartender4
local function scanAll()
    local count = scanBars(getSpellData());
    if IsAddOnLoaded("Bartender4") then
        count = scanBars(getSpellData(), count);
    end
    print("HealGuys Baby Spell Checker: " .. count .. " spells with lower ranks on hotbars.");
end

-- create the button on the spellbook frame
local button = CreateFrame("Button", "$parentButton", SpellBookFrame, "UIPanelButtonTemplate");
button:SetFrameLevel(15);
if (ElvUI) then
    button:SetPoint("TOPRIGHT", SpellBookFrame, "TOPRIGHT", -72, -34);
else
    button:SetPoint("TOPRIGHT", SpellBookFrame, "TOPRIGHT", -56, -52);
end
button:SetWidth(139);
button:SetHeight(25);
button:SetScale(1.0);
button:SetText("Check You Spells");
button:GetFontString():SetFontObject("GameFontNormalLarge");
button:GetFontString():SetTextColor(0, 1, 0);
button:SetScript("OnClick", function(self, arg)
    scanHotbars();
end)
